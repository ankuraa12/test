export const IndividualSearchDropDown: any = [
  { dropDown: 'PROV ID', value: 'provId' }, { dropDown: 'PFIN', value: 'pfin' },
  { dropDown: 'Bill PFIN', value: 'billPfin' },
  { dropDown: 'Bill PFIN First Name', value: 'billPfinFirstName' },
  { dropDown: 'Bill PFIN Last Name', value: 'billPfinLastName' },
  { dropDown: 'NPI', value: 'npi' },
  { dropDown: 'Tin', value: 'tin' }, { dropDown: 'PAL ID', value: 'palId' },
  { dropDown: 'First Name', value: 'firstName' }, { dropDown: 'Last Name', value: 'lastName' },
  { dropDown: 'License Number', value: 'licenseNumber' },
  { dropDown: 'Attestation Date', value: 'attestationDate' },
  { dropDown: 'Other Location ID', value: 'otherLocationId' }
]

export const GroupSearchDropDown: any = [
  { dropDown: 'PROV ID', value: 'provId' }, { dropDown: 'PFIN', value: 'pfin' },
  { dropDown: 'Bill PFIN', value: 'billPfin' },
  { dropDown: 'Bill PFIN Name', value: 'billPfinName' },
  { dropDown: 'NPI', value: 'npi' },
  { dropDown: 'Tin', value: 'tin' }, { dropDown: 'PAL ID', value: 'palId' },
  { dropDown: 'Name', value: 'name' },
  { dropDown: 'License Number', value: 'licenseNumber' },
  { dropDown: 'Attestation Date', value: 'attestationDate' },
  { dropDown: 'Other Location ID', value: 'otherLocationId' }
]

export const FilterCriteria = {
  CONTAINS: 'Contains',
  NOT_CONTAINS: 'Not contains',
  EQUALS: 'Equals',
  NOT_EQUAL: 'Not equal',
  STARTS_WITH: 'Starts with',
  ENDS_WITH: 'Ends with',
  GREATER: 'Greater than',
  GREATER_EQ: 'Greater than or equals',
  LESSER: 'Less than',
  LESSER_EQ: 'Less than or equals',
  IN_RANGE: 'In range'
};
