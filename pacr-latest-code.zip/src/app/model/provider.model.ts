interface IObjectKeys {
    [key: string]: string | number | any;
}

export interface ProviderJson extends IObjectKeys {
    provId: number;
    pfin: number;
    billPfin: number;
    billPfinName: string;
    billPfinFirstName: string;
    billPfinLastName: string;
    npi: number;
    tin: number;
    palId: number;
    firstName: string;
    lastName: string;
    name: string;
    licenseNumber: string;
    attestationDateFrom: string;
    attestationDateTo: string;
    otherLocationId: number;
}