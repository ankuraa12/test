import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConfigureComponent } from './components/configure/configure.component';
import { ReportComponent } from './components/report/report.component';
import { SearchComponent } from './components/search/search.component';

const routes: Routes = [
  { path: 'search', component: SearchComponent },
  { path: 'report', component: ReportComponent },
  { path: 'configure', component: ConfigureComponent },
  // { path: '', redirectTo: '/login', pathMatch: 'full'}
  { path: '**', redirectTo: 'search', }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
