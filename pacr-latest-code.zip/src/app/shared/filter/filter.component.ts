import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FilterCriteria } from 'src/app/constants/constants';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit{

  constructor(private formBuilder: FormBuilder) { }
  filterForm: FormGroup = new FormGroup({});
  filterOptions: string[] = [];
  // ['Contains', 'Not contains', 'Equals', 'Not equal', 'Starts with', 'Ends with', 'Greater than',
  // 'Greater than or equals', 'Less than', 'Less than or equals']
  @Output() emitFilter = new EventEmitter<FilterModel>();
  @Input() columnName: string = '';
  @Input() columnDataType: string = '';
  @Input() reset = { isReset: false };
  ngOnInit(): void {
    if (this.columnDataType === 'number') {
      this.filterOptions = ['Equals', 'Not equal', 'Greater than', 'Greater than or equals',
        'Less than', 'Less than or equals', 'In range'];
    }
    else if (this.columnDataType === 'string') {
      this.filterOptions = ['Contains', 'Not contains', 'Equals', 'Not equal', 'Starts with', 'Ends with'];
    }
    else if (this.columnDataType === 'date') {
      this.filterOptions = ['Equals', 'Not equal', 'Greater than', 'Less than', 'In range'];
    }
    this.filterForm = this.formBuilder.group({
      filterOpt: [this.filterOptions[0]],
      filterValue: [''],
      filterValueTo: [''],
      cName: this.columnName
    });
  }
  reset1(){
    this.reset.isReset=true;
  }
  ngDoCheck() {
    if (this.reset.isReset) {
      this.filterForm.reset({
        filterOpt: this.filterOptions[0],
        filterValue:'',
        filterValueTo: null,
        cName: this.columnName
      });
      this.sendFilterData();
    }
  }

  getPlaceholder() {
    if (this.filterForm.controls.filterOpt.value === FilterCriteria.IN_RANGE) {
      return 'From';
    }
    return 'Filter...';
  }

  sendFilterData() {
    // this.filterForm.controls.filterOpt
    this.emitFilter.emit({
      filterOpt: this.filterForm.controls.filterOpt.value,
      filterValue: this.filterForm.controls.filterValue.value,
      filterValueTo: this.filterForm.controls.filterValueTo.value,
      columnName: this.columnName,
      columnDataType: this.columnDataType
    });
  }
}

export interface FilterModel {
  filterOpt: string;
  filterValue: string;
  filterValueTo: string;
  columnName: any;
  columnDataType: string;
}
