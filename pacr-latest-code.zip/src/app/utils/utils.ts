export const StringColumns = ["billPfinName","firstName","lastName", "name",
  "addrLine1", "addrLine2", "street", "city", "state", "county","specialty",
]
export const NumberColumns = ["provId", "pfin", "billPfin","npi", "tin", "palId",
  "addrLine1", "addrLine2", "street", "city", "state", "county","specialty","zip", "phone","licN",
  "corpEntityCode",
]
// ["provId", "pfin", "billPfin", "billPfinName", "npi", "tin", "padId","firstName","lastName", "name",
//   "addrLine1", "addrLine2", "street", "city", "state", "county", "zip", "phone",  "specialty", "licN",
//   "corpEntityCode",
//   "attestationDate",
  
//   ];

export const GetDataTypeOfColumn = (columnName: string): string => {


    if(StringColumns.includes(columnName)){
        return 'string';
    } else if(NumberColumns.includes(columnName)){
        return 'number';
    } else if (columnName == 'attestationDate'){
        return 'date';
    } else{
        return "";
    }
    // switch (columnName) {
    //     case ColumnNames.PROVIDER_ID:
    //     case ColumnNames.PAL_ID:
    //         return 'number';
    //     case ColumnNames.NAME:
    //     case ColumnNames.BILL_PFIN_NAME:
    //         return 'string';
    //     case ColumnNames.ATTESTATION_DATE:
    //         return 'date';
    //     default:
    //         return '';
    // }
}