import { Pipe, PipeTransform } from '@angular/core';
import * as _ from "lodash";

@Pipe({
  name: 'titleCaseSpace'
})
export class TitleCaseSpacePipe implements PipeTransform {

  public transform(input: string): string {
    if(input == '' || input == " "){
      return ""
    } else{
      return _.startCase(input);
    }
    
  }

}
