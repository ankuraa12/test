import { TitleCaseSpacePipe } from './title-case-space.pipe';

describe('TitleCaseSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new TitleCaseSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
