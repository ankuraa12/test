import { Component, OnInit, ViewChild, AfterViewChecked, ElementRef, Renderer2 } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { SearchService } from 'src/app/services/search.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort'
import { FilterModel } from '../../shared/filter/filter.component';
import { GetDataTypeOfColumn } from '../../utils/utils';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { IndividualSearchDropDown, GroupSearchDropDown, FilterCriteria } from '../../constants/constants'
import { ProviderJson } from 'src/app/model/provider.model';
import * as moment from 'moment';
import { filter } from 'lodash';
import { FilterComponent } from 'src/app/shared/filter/filter.component'
import { BlockLike } from 'typescript';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit, AfterViewChecked {

  public providerForm: FormGroup;
  submitted: boolean = false;
  isDate: boolean = false;
  alreadyAddedSearch: boolean = false;
  providerControl: any;
  duplicateValues: any[] = [];
  searchType: any;
  showSearchFields: boolean = false;
  providerDateControl: any;
  firstNameAdded: boolean = false;
  lastNameAdded: boolean = false;
  billPfinFirstNameAdded: boolean = false;
  billPfinLastNameAdded: boolean = false;
  isEmptyForm: boolean = true;
  indChecked: boolean = true;
  orgChecked: boolean = false
  providerFieldsDropDown: any;
  clearButtonEnable:boolean=false;
  @ViewChild('tableParent')
  tableParent!: ElementRef;
  @ViewChild('searchBlock')
  searchBlock!: ElementRef;
  @ViewChild('parentBlock')
  parentBlock!: ElementRef;
  loader: boolean = false;

  /* New variables*/
  dataSource!: MatTableDataSource<any>;
  @ViewChild(MatSort)
  sort!: MatSort;
  displayedColumns: string[] = ["provId", "pfin", "billPfin", "billPfinName", "npi", "tin", "palId", "firstName", "lastName", "name",
    "addrLine1", "addrLine2", "street", "city", "state", "county", "zip", "phone", "specialty", "licN",
    "corpEntityCode",
    "attestationDate",
    "email",
    "otherLocationId", "url",
  ];
  filterColumns: string[] = ["provId", "pfin", "billPfin", "billPfinName", "npi", "tin", "palId", "name", "licN",
    "attestationDate",
    "otherLocationId"
  ];
  max = 180;
  current = 12;
  masterData: any = [];
  filteredData: any = [];
  appliedFIlters: FilterModel[] = [];
  resetObj = { isReset: false };
  @ViewChild(FilterComponent,{static: false}) appf:FilterComponent;

  constructor(private formBuilder: FormBuilder, private searchData: SearchService,
    public dialog: MatDialog, private renderer: Renderer2) {
  }

  ngOnInit(): void {
    this.providerForm = this.formBuilder.group({
      providerFields: this.formBuilder.array([this.createProviderFormGroup()])
    });
    this.providerControl = (this.providerForm.get('providerFields') as FormArray).controls;
    this.searchType = "Individual";
    this.providerFieldsDropDown = IndividualSearchDropDown;
  }

  ngAfterViewChecked() {
    this.dataSource = this.dataSource = new MatTableDataSource(this.filteredData);
    this.dataSource.sort = this.sort;
    this.getSubData(this.current);
    if (this.tableParent && this.searchBlock) {
      const height = window.innerHeight - this.searchBlock.nativeElement.offsetHeight - 59;
      var heightF = `${height}px`;
      this.renderer.setStyle(this.tableParent.nativeElement, "height", heightF);
    }
  }

  private createProviderFormGroup(): FormGroup {
    return new FormGroup({
      'providerField': new FormControl('', Validators.required),
      'providerValue': new FormControl('', Validators.required)
    })
  }

  setSearchTypeValue() {
    if (this.searchType == "Individual") {
      this.providerFieldsDropDown = IndividualSearchDropDown;
    } else if (this.searchType == "Organization") {
      this.providerFieldsDropDown = GroupSearchDropDown;
    }
  }

  onSelect(e: any) {
    this.isEmptyForm = false;
    this.lastNameAdded = false;
    this.firstNameAdded = false;
    this.billPfinFirstNameAdded = false;
    this.billPfinLastNameAdded = false;
    let counterForControls = 0;
    this.duplicateValues = [];
    this.providerControl.forEach((x: FormGroup) => {
      if (x.controls.providerField.value === e.value) {
        if (counterForControls > 0) {
          this.alreadyAddedSearch = true;
          this.duplicateValues.push(e.value);
        }
        counterForControls++;
      }
    });
    if (this.duplicateValues.length === 0) {
      this.providerControl.forEach((x: FormGroup) => {
        if (x.controls.providerField.value == 'firstName') {

          this.firstNameAdded = true;
        } else if (x.controls.providerField.value == 'lastName') {
          this.lastNameAdded = true;
        } else if (x.controls.providerField.value == 'billPfinFirstName') {
          this.billPfinFirstNameAdded = true;
        } else if (x.controls.providerField.value == 'billPfinLastName') {
          this.billPfinLastNameAdded = true;
        }
        if (x.controls.providerField.value === e.value) {
          x.controls.providerValue.reset();
          this.isDate = false;
          x.removeControl('dateV');
          x.controls.providerValue.setValidators([Validators.required]);
          x.controls.providerValue.updateValueAndValidity();
          this.alreadyAddedSearch = false;
          if (x.controls.providerField.value === 'provId' || x.controls.providerField.value === 'npi' ||
            x.controls.providerField.value === 'tin' || x.controls.providerField.value === 'palId' ||
            x.controls.providerField.value === 'licenseNumber' || x.controls.providerField.value === 'otherLocationId') {
            x.controls.providerValue.setValidators([Validators.required, Validators.pattern('[0-9]{10}')]);
          }
          else if (x.controls.providerField.value === 'attestationDate') {
            this.isDate = true;
            x.addControl('dateV', new FormGroup({
              fromDate: new FormControl('', Validators.required),
              toDate: new FormControl('', Validators.required)
            }))
            x.controls.providerValue.clearValidators();
            x.controls.providerValue.updateValueAndValidity();
            this.providerDateControl = x.controls.dateV as FormGroup;
          }
        }
      })
    }
  }

  public addProviderFormGroup() {
    const providerFields = this.providerForm.get('providerFields') as FormArray
    providerFields.push(this.createProviderFormGroup())
    if (this.tableParent && this.searchBlock) {
      const height = window.innerHeight - this.searchBlock.nativeElement.offsetHeight - 59;
      var heightF = `${height}px`;
      this.renderer.setStyle(this.tableParent.nativeElement, "height", heightF);
    }
  }

  public removeField(i: number) {
    const providerFields = this.providerForm.get('providerFields') as FormArray
    if (providerFields.length > 1) {
      const deletedElement = providerFields.at(i).value.providerField;
      var firstIndex = this.duplicateValues.findIndex(e => e == deletedElement);
      if (firstIndex >= 0) {
        this.duplicateValues.splice(firstIndex, 1);
      }
      if (this.duplicateValues.length == 0) {
        this.alreadyAddedSearch = false;
      }
      if (deletedElement == 'firstName') {

        this.firstNameAdded = false;
      } else if (deletedElement == 'lastName') {
        this.lastNameAdded = false;
      } else if (deletedElement == 'billPfinFirstName') {
        this.billPfinFirstNameAdded = false;
      } else if (deletedElement == 'billPfinLastName') {
        this.billPfinLastNameAdded = false;
      }
      providerFields.removeAt(i);
    } else {
      providerFields.reset();
      this.firstNameAdded = false;
      this.lastNameAdded = false;
      this.billPfinFirstNameAdded = false;
      this.billPfinLastNameAdded = false;
    }
  }

  submit() {
    this.loader = true;
    this.getData();
    this.submitted = true;
    const body: ProviderJson = {
      'provId': 0,
      'pfin': 0,
      'billPfin': 0,
      'billPfinName': '',
      'billPfinFirstName': '',
      'billPfinLastName': '',
      'npi': 0,
      'tin': 0,
      'palId': 0,
      'firstName': '',
      'lastName': '',
      'name': '',
      'licenseNumber': '',
      'otherLocationId': 0,
      'attestationDateFrom': '',
      'attestationDateTo': ''
    }

    this.providerForm.value.providerFields.forEach((element: { providerField: any; providerValue: any, dateV: any }) => {
      if (element.providerField == 'firstName') {
        this.firstNameAdded = true;
      } else if (element.providerField == 'lastName') {
        this.lastNameAdded = true;
      } else if (element.providerField == 'billPfinFirstName') {
        this.billPfinFirstNameAdded = true;
      } else if (element.providerField == 'billPfinLastName') {
        this.billPfinLastNameAdded = true;
      }
      Object.keys(body).forEach(jsonElement => {
        if (jsonElement == element.providerField) {
          body[jsonElement] = element.providerValue;
        } else if (element.providerField === 'attestationDate') {
          body['attestationDateFrom'] = moment(element.dateV.fromDate).format('MM/DD/YYYY');
          body['attestationDateTo'] = moment(element.dateV.toDate).format('MM/DD/YYYY');
        }
      })
    });
    if (this.lastNameAdded != this.firstNameAdded ||
      this.billPfinLastNameAdded != this.billPfinFirstNameAdded) {
      return;
    }
    /* Service Call Goes here */
    // this.searchData.getSearchResults(body).subscribe(result =>{
    // })
    if (this.tableParent && this.searchBlock) {
      // const screen = window.screen.height - 143
      // console.log(window.innerHeight);
      // console.log(window.screen.height);
      const height = window.innerHeight - this.searchBlock.nativeElement.offsetHeight - 59;
      var heightF = `${height}px`;
      this.renderer.setStyle(this.tableParent.nativeElement, "height", heightF);
    }
    this.loader = false;
  }

  checkDateControl(e: FormGroup) {
    if (e.controls.providerField.value === 'attestationDate') {
      return true;
    }
    else {
      return false;
    }
  }

  isDuplicateField() {
    if (this.duplicateValues.length > 0 && this.alreadyAddedSearch) {
      return true;
    }
    return false;
  }

  /*Infinite scroll starts */

  filterRequired(column: string) {
    if (this.filterColumns.includes(column)) {
      return true;
    }
    else {
      return false;
    }
  }

  getData() {
    this.masterData = ELEMENT_DATA;
    this.filteredData = ELEMENT_DATA;
    this.getSubData(this.current);
  }

  getSubData(index: number) {
    this.dataSource = new MatTableDataSource(this.filteredData.slice(0, index));
    this.dataSource.sort = this.sort;
  }
  scrollToggle:boolean=false;
  onScrollDown() {
    if (this.tableParent.nativeElement.scrollHeight - (this.tableParent.nativeElement.scrollTop + this.tableParent.nativeElement.offsetHeight) <= 100) {
       if (this.current < this.max) {
        this.current += 5
        this.getSubData(this.current);
      }
      else {
        console.log("No more data to show");
      }
    }
    else if(this.tableParent.nativeElement.scrollTop>50){
      this.scrollToggle=true;
    }
    else if(this.tableParent.nativeElement.scrollTop<50){
      this.scrollToggle=false;
    }  
  }

  getType(column: string) {
    return GetDataTypeOfColumn(column);
  }
scrolltop(){
  this.tableParent.nativeElement.scrollTop = 0;
}
  doit:boolean=false;
  resetAll() {
     this.resetObj.isReset = true;
  //   this.appliedFIlters= [];
  //   this.appf.filterForm.reset();
  //   this.dataSource.filter='';
  //   // this.doit=true;
  //   this.filterColumns.forEach(col => {
  //   this.appf.reset1();
  //   });
  //   this.appf.ngDoCheck();
  } 

  //For scrolling to Top button functionality
  // scrollToTop(){
  //   this.tableParent.nativeElement.scrollTop = 0;
  //   this.scrollToggle=false;
  // }

  filterData(event: FilterModel) {
    this.current = 12;
    this.filteredData = this.masterData;
    this.getSubData(this.masterData.length);
    if (this.resetObj.isReset) {
      this.appliedFIlters = [];
      this.appf.filterForm.reset();
      this.resetObj.isReset = false;
    }
    else {
      if (this.appliedFIlters.length > 0) {

        this.appliedFIlters.forEach((filter, index) => {
          if (filter.columnName === event.columnName) {
            this.appliedFIlters[index] = event;
          }
          else {
            this.appliedFIlters.push(event);
          }
        })
      }
      else {
        this.appliedFIlters.push(event);
      }

      for (let i = 0; i < this.appliedFIlters.length; i++) {
        this.displayedColumns.forEach(q => {
          if (q === this.appliedFIlters[i].columnName && this.appliedFIlters[i].filterValue) {
            let filterOpt = this.appliedFIlters[i].filterOpt;
            let filterType = this.appliedFIlters[i].columnDataType;
            let fromFilter = this.appliedFIlters[i].filterValue;
            let toFilter = this.appliedFIlters[i].filterValueTo;
            let formatDate = function (date: string) {
              let val = new Date(date);
              return val.getMonth() + '/' + val.getDate() + '/' + val.getFullYear();
            }
            this.dataSource.filterPredicate = function (data, filter: string): boolean {
              let result = false;
              if (filterOpt === FilterCriteria.CONTAINS) {
                result = data[q].toString().toLowerCase().includes(filter);
              }
              else if (filterOpt === FilterCriteria.NOT_CONTAINS) {
                result = !data[q].toString().toLowerCase().includes(filter);
              }
              else if (filterOpt === FilterCriteria.STARTS_WITH) {
                result = data[q].toString().toLowerCase().startsWith(filter);
              }
              else if (filterOpt === FilterCriteria.ENDS_WITH) {
                result = data[q].toString().toLowerCase().endsWith(filter);
              }
              else if (filterOpt === FilterCriteria.EQUALS) {
                result = q === 'attestationDate' ? formatDate(data[q]) === formatDate(filter) : data[q]?.toString().toLowerCase() == (filter);
              }
              else if (filterOpt === FilterCriteria.NOT_EQUAL) {
                result = q === 'attestationDate' ? formatDate(data[q]) != formatDate(filter) : data[q]?.toString().toLowerCase() != (filter);
              }
              else if (filterOpt === FilterCriteria.GREATER) {
                result = q === 'attestationDate' ? new Date(formatDate(data[q])) > new Date(formatDate(filter)) : data[q] > (filter);
              }
              else if (filterOpt === FilterCriteria.GREATER_EQ) {
                result = q === 'attestationDate' ? new Date(formatDate(data[q])) >= new Date(formatDate(filter)) : data[q] >= (filter);
              }
              else if (filterOpt === FilterCriteria.LESSER) {
                result = q === 'attestationDate' ? new Date(formatDate(data[q])) < new Date(formatDate(filter)) : data[q] < (filter);
              }
              else if (filterOpt === FilterCriteria.LESSER_EQ) {
                result = q === 'attestationDate' ? new Date(formatDate(data[q])) <= new Date(formatDate(filter)) : data[q] <= (filter);
              }
              else if (filterOpt === FilterCriteria.IN_RANGE) {
                result = q === 'attestationDate' ? (new Date(formatDate(data[q])) >= new Date(formatDate(fromFilter)) &&
                  new Date(formatDate(data[q])) <= new Date(formatDate(toFilter))) : (data[q] >= (fromFilter)) && (data[q] <= (toFilter));
              }
              return result;
            }
            let filterValue = this.appliedFIlters[i].filterValue.trim();
            filterValue = filterValue.toLowerCase();
            this.dataSource.filter = filterValue;
            this.filteredData = this.dataSource.filteredData;
            this.getSubData(this.current);
          }
        });
      };
    }

  }

  setSearchType(event: any, newSearchType: string) {

    if (!this.isEmptyForm) {
      event.preventDefault();
      let dialogRef = this.dialog.open(DialogComponent, {
        width: '350px',
        disableClose: true
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          event.checked = true;
          this.searchType = newSearchType;
          this.removeFields();
          this.setSearchTypeValue();
        }
      })
    } else {
      this.searchType = newSearchType;
      this.setSearchTypeValue();
    }
  }



  resetFields(): void {
    let dialogRef = this.dialog.open(DialogComponent, {
      width: '350px',
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.removeFields();
        this.submitted = false;
      }
    })
  }

  removeFields() {
    const providerFields = this.providerForm.get('providerFields') as FormArray
    const providerFieldLength = providerFields.length;
    this.duplicateValues = [];
    for (var i = providerFieldLength - 1; i >= 0; i--) {
      providerFields.removeAt(i);
    }
    this.addProviderFormGroup();
    this.isEmptyForm = true;
  }

  getMandatoryDateError() {
    return ((!this.providerDateControl.controls.fromDate.hasError('matDatepickerParse') &&
      this.providerDateControl.controls.fromDate.hasError('required') &&
      this.providerDateControl.controls.fromDate.touched &&
      !this.providerDateControl.controls.fromDate.value) ||
      (!this.providerDateControl.controls.toDate.hasError('matDatepickerParse') &&
        this.providerDateControl.controls.toDate.hasError('required') &&
        this.providerDateControl.controls.toDate.touched &&
        !this.providerDateControl.controls.toDate.value))
  }
}






const ELEMENT_DATA: any[] = [
  {
    "provId": 1431451,
    "pfin": 1234,
    "billPfin": 42342,
    "billPfinName": "bPfinNAME1",
    "npi": "sad asd",
    "tin": "234asda",
    "firstName": "Dhinesh chan",
    "lastName": "Chandramohan",
    "name": "name is small",
    "palId": 11,
    "addrLine1": "77, 6th cross sastry road", "addrLine2": "gr towers kailsash nagar"
    , "street": "Anna Salai"
    , "city": "Tiruchirappalli",
    "state": "Tamil Nadu",
    "county": "India",
    "zip": 620019,
    "phone": 989998877, "url": "https://www.instragram.com", "specialty": "some Speciality", "licN": 23423, "corpEntityCode": "qrqwe234", "email": "abc@defg.com",
    "otherLocationId": 12341,
    "attestationDate": "04/05/2020"
  },
  {
    "provId": 423424234,
    "pfin": 122342334,
    "billPfin": 4234232342,
    "billPfinName": "bPfinNAME312312",
    "npi": "sad asd",
    "tin": "234asda",
    "firstName": "Dhinesh chan",
    "lastName": "Chandramohan",
    "name": "name is small",
    "palId": 11,
    "addrLine1": "77, 6th cross sastry road", "addrLine2": "gr towers kailsash nagar"
    , "street": "Anna Salai EAST ROAD"
    , "city": "Tiruchirappalli JN",
    "state": "Tamil Nadu",
    "county": "India",
    "zip": 620019,
    "phone": 989998877, "url": "https://www.twitter.com", "specialty": "some Speciality", "licN": 2342234233, "corpEntityCode": "qrqwe234", "email": "abc@defg.com",
    "otherLocationId": 12341,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 3,
    "billPfinName": "3bPfinName",
    "name": "name3Val",
    "palId": 33,
    "attestationDate": "02/05/2018"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName3",
    "name": "nameVa4l",
    "palId": 14,
    "attestationDate": "04/05/2017"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 101,
    "attestationDate": "04/03/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPf1inName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "24/05/2018"
  },
  {
    "providerId": 3,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 33,
    "attestationDate": "06/08/2019"
  },
  {
    "providerId": 14,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "04/02/2019"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "04/05/2019"
  },
  {
    "providerId": 29,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/01/2020"
  },
  {
    "providerId": 30,
    "billPfinName": "bPf2inName",
    "name": "name9Val",
    "palId": 93,
    "attestationDate": "19/05/2020"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "09/12/2018"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "04/12/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "19/05/2020"
  },
  {
    "providerId": 3,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 33,
    "attestationDate": "08/10/2017"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "07/10/2018"
  },
  {
    "providerId": 72,
    "billPfinName": "b2PfinName",
    "name": "nameV2al",
    "palId": 822,
    "attestationDate": "01/01/2019"
  },
  {
    "providerId": 12,
    "billPfinName": "1bPfinName",
    "name": "nameVal1",
    "palId": 22,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/11/2019"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "30/12/2017"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/05/2019"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName1",
    "name": "nameVal0",
    "palId": 11,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName2",
    "name": "nameVal1",
    "palId": 12,
    "attestationDate": "14/05/2020"
  },
  {
    "providerId": 3,
    "billPfinName": "3bPfinName",
    "name": "name3Val",
    "palId": 33,
    "attestationDate": "02/05/2018"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName3",
    "name": "nameVa4l",
    "palId": 14,
    "attestationDate": "04/05/2017"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 101,
    "attestationDate": "04/03/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPf1inName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "24/05/2018"
  },
  {
    "providerId": 3,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 33,
    "attestationDate": "06/08/2019"
  },
  {
    "providerId": 14,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "04/02/2019"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "04/05/2019"
  },
  {
    "providerId": 29,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/01/2020"
  },
  {
    "providerId": 30,
    "billPfinName": "bPf2inName",
    "name": "name9Val",
    "palId": 93,
    "attestationDate": "19/05/2020"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "09/12/2018"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "04/12/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "19/05/2020"
  },
  {
    "providerId": 3,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 33,
    "attestationDate": "08/10/2017"
  },
  {
    "providerId": 4,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 44,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 1,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 11,
    "attestationDate": "07/10/2018"
  },
  {
    "providerId": 72,
    "billPfinName": "b2PfinName",
    "name": "nameV2al",
    "palId": 822,
    "attestationDate": "01/01/2019"
  },
  {
    "providerId": 12,
    "billPfinName": "1bPfinName",
    "name": "nameVal1",
    "palId": 22,
    "attestationDate": "04/05/2020"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/11/2019"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "30/12/2017"
  },
  {
    "providerId": 2,
    "billPfinName": "bPfinName",
    "name": "nameVal",
    "palId": 22,
    "attestationDate": "04/05/2019"
  }
];

